# Talkie ProGuard rules (release builds currently ship unminified).
-keepattributes SourceFile,LineNumberTable
