package com.ahaan.talkie.data

/**
 * Repository contract the UI depends on.
 *
 * Today the only implementation is [LocalChatRepository], backed by
 * [DemoRepository]. When google-services.json is added and Firebase Auth +
 * Firestore are enabled in the console, a FirestoreChatRepository can be
 * dropped in behind this same interface without touching any Activity:
 *
 *   Firestore plug-in points (already scaffolded in [FirestoreSync]):
 *   - messages: collection "messages", one document per [Message]
 *   - chats:    collection "chats", one document per [Chat]
 *   - presence: users/{uid} document with isOnline + lastSeen fields
 *   - media:    Firebase Storage under media/{chatId}/{messageId}
 *   - push:     FCM via [com.ahaan.talkie.fcm.TalkieMessagingService]
 */
interface ChatRepository {
    fun chats(): List<Chat>
    fun messages(chatId: String): List<Message>
    fun send(message: Message)
}

class LocalChatRepository : ChatRepository {
    override fun chats(): List<Chat> = DemoRepository.chats
    override fun messages(chatId: String): List<Message> = DemoRepository.messagesFor(chatId)
    override fun send(message: Message) = DemoRepository.sendMessage(message.chatId, message)
}

object RepositoryProvider {
    val chatRepository: ChatRepository = LocalChatRepository()
}
