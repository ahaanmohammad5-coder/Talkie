package com.ahaan.talkie.ui

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.location.LocationManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.Window
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.Chat
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.data.Message
import com.ahaan.talkie.data.MessageStatus
import com.ahaan.talkie.data.MessageType
import com.ahaan.talkie.util.AvatarUtils
import com.ahaan.talkie.util.TimeUtils
import java.io.File
import java.io.FileOutputStream

/**
 * One conversation. Handles text, images, videos, circular video notes,
 * stickers (built-in + make-your-own), location, documents and voice notes,
 * plus the presence header and the pending/sent/delivered/read tick flow
 * driven by [DemoRepository].
 */
class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CHAT_ID = "extra_chat_id"
        private const val REQ_LOCATION = 2001
        private const val REQ_AUDIO = 2002
    }

    private lateinit var chat: Chat
    private lateinit var adapter: MessagesAdapter
    private lateinit var messagesList: RecyclerView
    private lateinit var input: EditText
    private lateinit var sendOrMic: ImageButton
    private lateinit var presenceView: TextView
    private lateinit var stickerPanel: View
    private lateinit var myStickerAdapter: StickerAdapter

    private val handler = Handler(Looper.getMainLooper())
    private var lastMessageCount = 0

    private val repoListener: () -> Unit = { refreshAll() }

    // ------------------------- pickers / intents -------------------------

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendMedia(MessageType.IMAGE, uri.toString())
    }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendMedia(MessageType.VIDEO, uri.toString())
    }

    private val pickDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = queryDisplayName(uri) ?: "Document"
            sendText("Document shared: $name")
        }
    }

    private val cameraCapture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val bmp = result.data?.extras?.get("data") as? Bitmap
        if (result.resultCode == Activity.RESULT_OK && bmp != null) {
            val file = File(cacheDir, "photo_" + System.currentTimeMillis() + ".jpg")
            FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 90, out) }
            sendMedia(MessageType.IMAGE, "file://" + file.absolutePath)
        }
    }

    private val videoNoteCapture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null) {
            sendMedia(MessageType.VIDEO_NOTE, uri.toString())
        }
    }

    private val stickerImagePick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) createStickerFrom(uri)
    }

    // ------------------------------ lifecycle ----------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val chatId = intent.getStringExtra(EXTRA_CHAT_ID)
        val found = chatId?.let { DemoRepository.chatById(it) }
        if (found == null) {
            finish()
            return
        }
        chat = found
        DemoRepository.markChatRead(chat.id)

        bindHeader()
        bindMessages()
        bindInputBar()
        bindStickerPanel()
        refreshAll()
    }

    override fun onStart() {
        super.onStart()
        DemoRepository.addListener(repoListener)
        refreshAll()
    }

    override fun onStop() {
        DemoRepository.removeListener(repoListener)
        super.onStop()
    }

    override fun onDestroy() {
        stopRecording(send = false)
        if (::adapter.isInitialized) adapter.releasePlayer()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------ header -------------------------------

    private fun bindHeader() {
        AvatarUtils.applyAvatar(findViewById(R.id.chatHeaderAvatar), chat.title)
        findViewById<TextView>(R.id.chatHeaderName).text = chat.title
        presenceView = findViewById(R.id.chatHeaderPresence)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnVoiceCall).setOnClickListener { openCall(false) }
        findViewById<View>(R.id.btnVideoCall).setOnClickListener { openCall(true) }
        findViewById<View>(R.id.btnChatMore).setOnClickListener { v -> showChatMenu(v) }
    }

    private fun openCall(isVideo: Boolean) {
        val intent = Intent(this, CallActivity::class.java)
        intent.putExtra(CallActivity.EXTRA_NAME, chat.title)
        intent.putExtra(CallActivity.EXTRA_CONTACT_ID, chat.contactId)
        intent.putExtra(CallActivity.EXTRA_IS_VIDEO, isVideo)
        startActivity(intent)
    }

    private fun showChatMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_chat, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.chat_view_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java)); true
                }
                R.id.chat_search -> {
                    Toast.makeText(this, "Search is coming soon", Toast.LENGTH_SHORT).show(); true
                }
                R.id.chat_clear -> {
                    DemoRepository.clearChat(chat.id); true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun refreshPresence() {
        if (!::presenceView.isInitialized) return
        if (DemoRepository.isTyping(chat.id)) {
            presenceView.text = getString(R.string.typing)
            presenceView.setTextColor(ContextCompat.getColor(this, R.color.green_badge))
            return
        }
        if (chat.isGroup) {
            val names = chat.memberIds.mapNotNull { DemoRepository.contactById(it)?.name?.substringBefore(" ") }
            presenceView.text = if (names.isEmpty()) "Group" else names.joinToString(", ")
            presenceView.setTextColor(ContextCompat.getColor(this, R.color.beige_accent))
            return
        }
        val contact = DemoRepository.contactById(chat.contactId)
        if (contact != null && contact.isOnline) {
            // User rule: "online" written under the name when online.
            presenceView.text = getString(R.string.online)
            presenceView.setTextColor(ContextCompat.getColor(this, R.color.beige_on_green))
        } else {
            presenceView.text = contact?.lastSeen ?: ""
            presenceView.setTextColor(ContextCompat.getColor(this, R.color.beige_accent))
        }
    }

    // ----------------------------- messages ------------------------------

    private fun bindMessages() {
        messagesList = findViewById(R.id.messagesList)
        messagesList.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        adapter = MessagesAdapter(
            chat = chat,
            onMediaClick = { msg -> onMediaClicked(msg) },
            onLocationClick = { msg -> openLocation(msg) }
        )
        messagesList.adapter = adapter
    }

    private fun onMediaClicked(msg: Message) {
        when (msg.type) {
            MessageType.IMAGE -> showImageDialog(msg.mediaUri)
            MessageType.VIDEO, MessageType.VIDEO_NOTE -> {
                val intent = Intent(this, VideoPlayerActivity::class.java)
                intent.putExtra(VideoPlayerActivity.EXTRA_URI, msg.mediaUri)
                startActivity(intent)
            }
            else -> Unit
        }
    }

    private fun showImageDialog(uriString: String?) {
        if (uriString == null) return
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val image = ImageView(this)
        image.adjustViewBounds = true
        image.setImageURI(Uri.parse(uriString))
        image.setOnClickListener { dialog.dismiss() }
        dialog.setContentView(image)
        dialog.window?.setLayout(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
    }

    private fun openLocation(msg: Message) {
        val lat = msg.latitude ?: return
        val lng = msg.longitude ?: return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=$lat,$lng"))
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No maps app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshAll() {
        if (!::adapter.isInitialized) return
        val list = DemoRepository.messagesFor(chat.id).toList()
        adapter.submit(list)
        if (list.size != lastMessageCount) {
            lastMessageCount = list.size
            if (list.isNotEmpty()) messagesList.scrollToPosition(list.size - 1)
        }
        refreshPresence()
    }

    // ------------------------------ sending ------------------------------

    private fun sendText(text: String) {
        val msg = Message(
            chatId = chat.id,
            senderId = DemoRepository.ME,
            text = text,
            time = TimeUtils.nowLabel(),
            status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
        )
        DemoRepository.sendMessage(chat.id, msg)
    }

    private fun sendMedia(type: MessageType, uriString: String) {
        val msg = Message(
            chatId = chat.id,
            senderId = DemoRepository.ME,
            type = type,
            mediaUri = uriString,
            time = TimeUtils.nowLabel(),
            status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
        )
        DemoRepository.sendMessage(chat.id, msg)
    }

    // ------------------------------ input bar ----------------------------

    private fun bindInputBar() {
        input = findViewById(R.id.messageInput)
        sendOrMic = findViewById(R.id.btnSendOrMic)
        stickerPanel = findViewById(R.id.stickerPanel)

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val hasText = !s.isNullOrBlank()
                sendOrMic.setImageResource(if (hasText) R.drawable.ic_send else R.drawable.ic_mic)
            }
        })

        sendOrMic.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                sendText(text)
                input.text.clear()
            } else {
                toggleVoiceRecording()
            }
        }

        findViewById<View>(R.id.btnEmoji).setOnClickListener { toggleStickerPanel() }
        findViewById<View>(R.id.btnSticker).setOnClickListener { toggleStickerPanel() }
        findViewById<View>(R.id.btnAttach).setOnClickListener { v -> showAttachMenu(v) }
        findViewById<View>(R.id.btnCamera).setOnClickListener {
            runCatching { cameraCapture.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) }
                .onFailure { Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show() }
        }
        findViewById<View>(R.id.btnVideoNote).setOnClickListener {
            runCatching { videoNoteCapture.launch(Intent(MediaStore.ACTION_VIDEO_CAPTURE)) }
                .onFailure { Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun showAttachMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_attach, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.attach_gallery -> { pickImage.launch("image/*"); true }
                R.id.attach_video -> { pickVideo.launch("video/*"); true }
                R.id.attach_camera -> {
                    runCatching { cameraCapture.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) }
                    true
                }
                R.id.attach_location -> { shareLocation(); true }
                R.id.attach_document -> { pickDocument.launch(arrayOf("*/*")); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ----------------------------- location ------------------------------

    private fun shareLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION
            )
            return
        }
        sendCurrentLocation()
    }

    private fun sendCurrentLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        var best: android.location.Location? = null
        try {
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                val loc = lm.getLastKnownLocation(provider) ?: continue
                if (best == null || loc.time > (best?.time ?: 0)) best = loc
            }
        } catch (e: SecurityException) {
            // Permission was revoked between check and read.
        }
        val loc = best
        if (loc == null) {
            Toast.makeText(this, getString(R.string.location_unavailable), Toast.LENGTH_SHORT).show()
            return
        }
        val label = String.format("%.5f, %.5f", loc.latitude, loc.longitude)
        val msg = Message(
            chatId = chat.id,
            senderId = DemoRepository.ME,
            type = MessageType.LOCATION,
            text = "Shared location\n$label",
            latitude = loc.latitude,
            longitude = loc.longitude,
            time = TimeUtils.nowLabel(),
            status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
        )
        DemoRepository.sendMessage(chat.id, msg)
    }

    // ---------------------------- voice notes ----------------------------

    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var recordingStart: Long = 0
    private var recordingTimer: Runnable? = null

    private fun toggleVoiceRecording() {
        if (recorder != null) {
            stopRecording(send = true)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }
        startRecording()
    }

    private fun startRecording() {
        try {
            recordingFile = File(cacheDir, "voice_" + System.currentTimeMillis() + ".m4a")
            recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(recordingFile!!.absolutePath)
                prepare()
                start()
            }
            recordingStart = System.currentTimeMillis()
            findViewById<View>(R.id.recordingBar).visibility = View.VISIBLE
            findViewById<View>(R.id.inputBar).visibility = View.GONE
            val timerView = findViewById<TextView>(R.id.recordingTimer)
            recordingTimer = object : Runnable {
                override fun run() {
                    val sec = ((System.currentTimeMillis() - recordingStart) / 1000).toInt()
                    timerView.text = TimeUtils.formatDuration(sec)
                    handler.postDelayed(this, 500)
                }
            }
            handler.post(recordingTimer!!)
        } catch (e: Exception) {
            Toast.makeText(this, "Recording not available", Toast.LENGTH_SHORT).show()
            stopRecording(send = false)
        }
    }

    private fun stopRecording(send: Boolean) {
        val rec = recorder ?: return
        recorder = null
        recordingTimer?.let { handler.removeCallbacks(it) }
        recordingTimer = null
        try {
            rec.stop()
        } catch (e: Exception) {
            // Too-short recordings can throw on stop; just discard.
        }
        rec.release()
        findViewById<View>(R.id.recordingBar).visibility = View.GONE
        findViewById<View>(R.id.inputBar).visibility = View.VISIBLE
        val file = recordingFile
        recordingFile = null
        if (send && file != null && file.exists()) {
            val sec = (((System.currentTimeMillis() - recordingStart) / 1000).toInt()).coerceAtLeast(1)
            val msg = Message(
                chatId = chat.id,
                senderId = DemoRepository.ME,
                type = MessageType.VOICE,
                mediaUri = "file://" + file.absolutePath,
                durationSec = sec,
                time = TimeUtils.nowLabel(),
                status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
            )
            DemoRepository.sendMessage(chat.id, msg)
        }
    }

    // ----------------------------- stickers ------------------------------

    private fun toggleStickerPanel() {
        stickerPanel.visibility =
            if (stickerPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun bindStickerPanel() {
        val builtIns = listOf("😀", "😂", "😍", "😎", "🥳", "😴", "🤔", "🙏", "❤️", "🔥", "💯", "🎉", "👍", "🌙", "☕", "⚽")
            .map { StickerItem.Glyph(it) }
        val grid = findViewById<RecyclerView>(R.id.stickerGrid)
        grid.layoutManager = GridLayoutManager(this, 4)
        val builtInAdapter = StickerAdapter { item -> onStickerPicked(item) }
        grid.adapter = builtInAdapter
        builtInAdapter.submit(builtIns)

        val myGrid = findViewById<RecyclerView>(R.id.myStickerGrid)
        myGrid.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        myStickerAdapter = StickerAdapter { item -> onStickerPicked(item) }
        myGrid.adapter = myStickerAdapter
        refreshMyStickers()
    }

    private fun refreshMyStickers() {
        val dir = stickerDir()
        val files = dir.listFiles()
            ?.filter { it.extension.lowercase() == "png" }
            ?.sortedBy { it.lastModified() }
            ?: emptyList()
        val items = mutableListOf<StickerItem>(StickerItem.Create)
        files.forEach { items.add(StickerItem.Custom(it)) }
        myStickerAdapter.submit(items)
    }

    private fun onStickerPicked(item: StickerItem) {
        when (item) {
            is StickerItem.Glyph -> {
                val msg = Message(
                    chatId = chat.id,
                    senderId = DemoRepository.ME,
                    type = MessageType.STICKER,
                    stickerGlyph = item.glyph,
                    time = TimeUtils.nowLabel(),
                    status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
                )
                DemoRepository.sendMessage(chat.id, msg)
            }
            is StickerItem.Custom -> {
                val msg = Message(
                    chatId = chat.id,
                    senderId = DemoRepository.ME,
                    type = MessageType.STICKER,
                    stickerPath = item.file.absolutePath,
                    time = TimeUtils.nowLabel(),
                    status = if (DemoRepository.deviceOnline) MessageStatus.SENT else MessageStatus.PENDING
                )
                DemoRepository.sendMessage(chat.id, msg)
            }
            StickerItem.Create -> stickerImagePick.launch("image/*")
        }
    }

    private fun stickerDir(): File {
        val dir = File(filesDir, "stickers")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Simple sticker maker: center-crop to a square, add a white border. */
    private fun createStickerFrom(uri: Uri) {
        val source = loadBitmap(uri)
        if (source == null) {
            Toast.makeText(this, "Image could not be loaded", Toast.LENGTH_SHORT).show()
            return
        }
        val size = 512
        val border = 18
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = android.graphics.Color.WHITE
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)
        val side = minOf(source.width, source.height)
        val left = (source.width - side) / 2
        val top = (source.height - side) / 2
        val srcRect = android.graphics.Rect(left, top, left + side, top + side)
        val dstRect = android.graphics.Rect(border, border, size - border, size - border)
        canvas.drawBitmap(source, srcRect, dstRect, paint)

        val file = File(stickerDir(), "sticker_" + System.currentTimeMillis() + ".png")
        FileOutputStream(file).use { out -> output.compress(Bitmap.CompressFormat.PNG, 100, out) }
        refreshMyStickers()
        Toast.makeText(this, "Sticker saved to My stickers", Toast.LENGTH_SHORT).show()
    }

    private fun loadBitmap(uri: Uri): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        }
    } catch (e: Exception) {
        null
    }

    // ---------------------------- permissions ----------------------------

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_LOCATION -> if (granted) sendCurrentLocation()
                else Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
            REQ_AUDIO -> if (granted) startRecording()
                else Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
        }
    }
}
