package com.ahaan.talkie.data

import android.content.Context
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import com.ahaan.talkie.util.TimeUtils
import java.util.UUID

/**
 * Local demo repository.
 *
 * This is the single source of truth while the app runs without a
 * google-services.json file. It holds sample chats, contacts, statuses and
 * call history so the installed APK feels complete immediately, and it
 * simulates presence, typing, delivery ticks and replies.
 *
 * LIVE MODE: when Firebase is configured, [FirestoreSync] mirrors the very
 * same models to Firestore (collections: chats, messages, users, statuses).
 * The UI never talks to Firebase directly; it only observes this layer.
 */
object DemoRepository {

    const val ME = "me"

    val profile = MyProfile()

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = mutableSetOf<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun notifyChanged() {
        // Copy first: listeners may unregister themselves while running.
        listeners.toList().forEach { runCatching { it() } }
        FirestoreSync.onLocalDataChanged()
    }

    // ------------------------------------------------------------------
    // Connectivity + pending queue (no internet -> clock icon on bubble)
    // ------------------------------------------------------------------

    @Volatile
    var deviceOnline: Boolean = true
        private set

    private var connectivityStarted = false

    fun startConnectivity(context: Context) {
        if (connectivityStarted) return
        connectivityStarted = true
        val cm = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        deviceOnline = isCurrentlyOnline(cm)
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching {
            cm.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    handler.post {
                        deviceOnline = true
                        flushPendingQueue()
                        notifyChanged()
                    }
                }

                override fun onLost(network: Network) {
                    handler.post {
                        if (!isCurrentlyOnline(cm)) {
                            deviceOnline = false
                            notifyChanged()
                        }
                    }
                }
            })
        }
    }

    private fun isCurrentlyOnline(cm: ConnectivityManager): Boolean {
        val cap = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Sends everything that was waiting with a clock icon. */
    private fun flushPendingQueue() {
        var flushed = false
        messages.values.forEach { list ->
            list.filter { it.isMine && it.status == MessageStatus.PENDING }.forEach { msg ->
                progressOwnMessage(msg)
                flushed = true
            }
        }
        if (flushed) notifyChanged()
    }

    // ------------------------------------------------------------------
    // Sample contacts
    // ------------------------------------------------------------------

    val contacts: MutableList<Contact> = mutableListOf(
        Contact("c_ahmed", "Ahmed Raza", "+92 300 1112233", "Busy with design work", isOnline = true),
        Contact("c_fatima", "Fatima Noor", "+92 321 4455667", "Alhamdulillah", isOnline = true),
        Contact("c_ali", "Ali Hamza", "+92 333 9988776", "At the gym", isOnline = false, lastSeen = "last seen today at 9:41 AM"),
        Contact("c_zainab", "Zainab Tariq", "+92 345 2233445", "UI designer by day", isOnline = true),
        Contact("c_bilal", "Bilal Sheikh", "+92 301 6677889", "Available", isOnline = false, lastSeen = "last seen yesterday at 11:02 PM"),
        Contact("c_ayesha", "Ayesha Khan", "+92 312 3344556", "Coffee first", isOnline = true),
        Contact("c_hassan", "Hassan Javed", "+92 333 7788990", "Karachi", isOnline = false, lastSeen = "last seen today at 8:15 AM"),
        Contact("c_maryam", "Maryam Siddiqui", "+92 321 9900112", "Assalam o Alaikum", isOnline = true)
    )

    fun contactById(id: String?): Contact? = contacts.firstOrNull { it.id == id }

    // ------------------------------------------------------------------
    // Sample chats + messages
    // ------------------------------------------------------------------

    val chats: MutableList<Chat> = mutableListOf()
    private val messages: MutableMap<String, MutableList<Message>> = mutableMapOf()
    private val typingChats: MutableSet<String> = mutableSetOf()

    fun messagesFor(chatId: String): MutableList<Message> =
        messages.getOrPut(chatId) { mutableListOf() }

    fun isTyping(chatId: String): Boolean = typingChats.contains(chatId)

    init {
        seed()
    }

    private fun seedMessage(chatId: String, senderId: String, senderName: String, text: String, time: String, status: MessageStatus = MessageStatus.READ) {
        messagesFor(chatId).add(
            Message(chatId = chatId, senderId = senderId, senderName = senderName, text = text, time = time, status = status)
        )
    }

    private fun seed() {
        chats.addAll(
            listOf(
                Chat("chat_ahmed", "Ahmed Raza", contactId = "c_ahmed", lastMessage = "Kal demo ready rakhna", lastTime = "10:24 AM", lastStatus = MessageStatus.READ, lastFromMe = true, unread = 0),
                Chat("chat_family", "Family Group", isGroup = true, lastMessage = "Ammi: Sab khairiyat hai?", lastTime = "9:58 AM", unread = 3, memberIds = listOf("c_fatima", "c_ali", "c_maryam")),
                Chat("chat_fatima", "Fatima Noor", contactId = "c_fatima", lastMessage = "Poster bhej diya hai, dekh lena", lastTime = "9:12 AM", unread = 1),
                Chat("chat_office", "Office Team", isGroup = true, lastMessage = "Bilal: Meeting 3 baje hai", lastTime = "Yesterday", unread = 0, memberIds = listOf("c_bilal", "c_zainab", "c_hassan")),
                Chat("chat_ali", "Ali Hamza", contactId = "c_ali", lastMessage = "Gym kal pakka", lastTime = "Yesterday", lastStatus = MessageStatus.DELIVERED, lastFromMe = true),
                Chat("chat_zainab", "Zainab Tariq", contactId = "c_zainab", lastMessage = "Figma file share kar di", lastTime = "Yesterday", unread = 0),
                Chat("chat_bilal", "Bilal Sheikh", contactId = "c_bilal", lastMessage = "Invoice mil gaya, shukriya", lastTime = "Tuesday", lastStatus = MessageStatus.SENT, lastFromMe = true),
                Chat("chat_ayesha", "Ayesha Khan", contactId = "c_ayesha", lastMessage = "Wo wala color boht acha laga", lastTime = "Monday", unread = 0)
            )
        )

        seedMessage("chat_ahmed", "c_ahmed", "Ahmed Raza", "Assalam o Alaikum, client ne logo approve kar diya hai", "10:02 AM")
        seedMessage("chat_ahmed", ME, "", "Wa Alaikum Assalam, mubarak ho! Ab UI screens start kar dein?", "10:15 AM")
        seedMessage("chat_ahmed", "c_ahmed", "Ahmed Raza", "Han bilkul, kal demo hai to aaj hi start karte hain", "10:20 AM")
        seedMessage("chat_ahmed", ME, "", "Kal demo ready rakhna", "10:24 AM")

        seedMessage("chat_family", "c_maryam", "Maryam", "Kal dawat pakki hai, sab time par aa jana", "9:30 AM")
        seedMessage("chat_family", "c_fatima", "Fatima", "Main biryani banaungi InshaAllah", "9:45 AM")
        seedMessage("chat_family", "c_ali", "Ali", "Ammi: Sab khairiyat hai?", "9:58 AM")

        seedMessage("chat_fatima", "c_fatima", "Fatima Noor", "Kal walay design ka final version chahiye", "8:55 AM")
        seedMessage("chat_fatima", ME, "", "Main abhi bhejta hun, ek section reh gaya hai", "9:05 AM")
        seedMessage("chat_fatima", "c_fatima", "Fatima Noor", "Poster bhej diya hai, dekh lena", "9:12 AM")

        seedMessage("chat_office", "c_zainab", "Zainab", "Naya dashboard design dekh liya sab ne?", "Yesterday")
        seedMessage("chat_office", "c_bilal", "Bilal", "Meeting 3 baje hai", "Yesterday")

        seedMessage("chat_ali", "c_ali", "Ali Hamza", "Bro kal leg day hai, tayyar rehna", "Yesterday")
        seedMessage("chat_ali", ME, "", "Gym kal pakka", "Yesterday", MessageStatus.DELIVERED)

        seedMessage("chat_zainab", "c_zainab", "Zainab Tariq", "Tumhari portfolio site boht achi lagi", "Yesterday")
        seedMessage("chat_zainab", "c_zainab", "Zainab Tariq", "Figma file share kar di", "Yesterday")

        seedMessage("chat_bilal", "c_bilal", "Bilal Sheikh", "Payment ka scene clear hai?", "Tuesday")
        seedMessage("chat_bilal", ME, "", "Invoice mil gaya, shukriya", "Tuesday", MessageStatus.SENT)

        seedMessage("chat_ayesha", "c_ayesha", "Ayesha Khan", "Wo wala color boht acha laga", "Monday")
    }

    // ------------------------------------------------------------------
    // Sample statuses + call history
    // ------------------------------------------------------------------

    val statuses: MutableList<StatusItem> = mutableListOf(
        StatusItem("s1", "c_fatima", "Fatima Noor", "32 minutes ago", "Subah ki chai aur ye view", Color.parseColor("#7A4E2D")),
        StatusItem("s2", "c_ali", "Ali Hamza", "1 hour ago", "Leg day done. No excuses.", Color.parseColor("#3D5A80")),
        StatusItem("s3", "c_ayesha", "Ayesha Khan", "3 hours ago", "Naya sketch, kaisa laga?", Color.parseColor("#6D4C7D")),
        StatusItem("s4", "c_hassan", "Hassan Javed", "5 hours ago", "Karachi ki shaam", Color.parseColor("#2F6F6A"))
    )

    val callLogs: MutableList<CallLogItem> = mutableListOf(
        CallLogItem("cl1", "Ahmed Raza", "c_ahmed", CallDirection.OUTGOING, false, "Today, 10:05 AM"),
        CallLogItem("cl2", "Fatima Noor", "c_fatima", CallDirection.INCOMING, true, "Today, 8:47 AM"),
        CallLogItem("cl3", "Ali Hamza", "c_ali", CallDirection.MISSED, false, "Yesterday, 9:15 PM"),
        CallLogItem("cl4", "Zainab Tariq", "c_zainab", CallDirection.INCOMING, false, "Yesterday, 4:30 PM"),
        CallLogItem("cl5", "Bilal Sheikh", "c_bilal", CallDirection.OUTGOING, true, "Tuesday, 1:12 PM")
    )

    fun addCallLog(name: String, contactId: String?, isVideo: Boolean) {
        callLogs.add(
            0,
            CallLogItem(UUID.randomUUID().toString(), name, contactId, CallDirection.OUTGOING, isVideo, "Today, " + TimeUtils.nowLabel())
        )
        notifyChanged()
    }

    // ------------------------------------------------------------------
    // Sending + the tick state machine
    // ------------------------------------------------------------------

    private val replyPool = listOf(
        "Theek hai, ho jayega",
        "Kal milte hain phir, InshaAllah",
        "Haha, sahi kaha bilkul",
        "Ok main dekh leta hun abhi",
        "Bohat khoob! Aur sunao",
        "Abhi thora busy hun, dair se batata hun",
        "Done, bhej diya hai",
        "Shukriya! Tum sunao sab khairiyat?"
    )

    fun sendMessage(chatId: String, message: Message) {
        messagesFor(chatId).add(message)
        updateChatPreview(chatId, message)
        if (message.isMine) {
            if (!deviceOnline) {
                message.status = MessageStatus.PENDING
            } else {
                progressOwnMessage(message)
            }
            scheduleSimulatedReply(chatId)
        }
        notifyChanged()
        FirestoreSync.uploadMessage(message)
    }

    /** PENDING -> SENT -> (peer online) DELIVERED -> READ, with small delays. */
    private fun progressOwnMessage(message: Message) {
        val chat = chats.firstOrNull { it.id == message.chatId }
        val peerOnline = chat?.let { contactById(it.contactId)?.isOnline } ?: true
        message.status = MessageStatus.SENT
        syncChatStatus(message)
        if (peerOnline) {
            handler.postDelayed({
                if (message.status == MessageStatus.SENT) {
                    message.status = MessageStatus.DELIVERED
                    syncChatStatus(message)
                    notifyChanged()
                }
            }, 900)
            handler.postDelayed({
                if (message.status == MessageStatus.DELIVERED) {
                    message.status = MessageStatus.READ
                    syncChatStatus(message)
                    notifyChanged()
                }
            }, 2400)
        }
    }

    private fun syncChatStatus(message: Message) {
        val chat = chats.firstOrNull { it.id == message.chatId } ?: return
        if (chat.lastFromMe) chat.lastStatus = message.status
    }

    private fun scheduleSimulatedReply(chatId: String) {
        val chat = chats.firstOrNull { it.id == chatId } ?: return
        if (chat.isGroup) return
        val contact = contactById(chat.contactId) ?: return
        if (!contact.isOnline) return
        handler.postDelayed({
            typingChats.add(chatId)
            notifyChanged()
        }, 2600)
        handler.postDelayed({
            typingChats.remove(chatId)
            val reply = Message(
                chatId = chatId,
                senderId = contact.id,
                senderName = contact.name,
                text = replyPool.random(),
                time = TimeUtils.nowLabel(),
                status = MessageStatus.READ
            )
            messagesFor(chatId).add(reply)
            updateChatPreview(chatId, reply)
            notifyChanged()
        }, 3800)
    }

    private fun updateChatPreview(chatId: String, message: Message) {
        val chat = chats.firstOrNull { it.id == chatId } ?: return
        chat.lastMessage = when (message.type) {
            MessageType.TEXT -> message.text
            MessageType.IMAGE -> "Photo"
            MessageType.VIDEO -> "Video"
            MessageType.VIDEO_NOTE -> "Video message"
            MessageType.STICKER -> "Sticker"
            MessageType.LOCATION -> "Location"
            MessageType.VOICE -> "Voice message " + TimeUtils.formatDuration(message.durationSec)
        }
        if (message.isMine) {
            chat.lastFromMe = true
            chat.lastStatus = message.status
        } else {
            chat.lastFromMe = false
            chat.lastStatus = null
            if (message.senderName.isNotEmpty() && chat.isGroup) {
                chat.lastMessage = message.senderName.substringBefore(" ") + ": " + chat.lastMessage
            }
        }
        chat.lastTime = message.time
        // Move chat to top, like real messengers.
        chats.remove(chat)
        chats.add(0, chat)
    }

    fun clearChat(chatId: String) {
        messagesFor(chatId).clear()
        val chat = chats.firstOrNull { it.id == chatId }
        if (chat != null) {
            chat.lastMessage = ""
            chat.unread = 0
        }
        notifyChanged()
    }

    fun markChatRead(chatId: String) {
        val chat = chats.firstOrNull { it.id == chatId } ?: return
        if (chat.unread != 0) {
            chat.unread = 0
            notifyChanged()
        }
    }

    fun chatById(id: String): Chat? = chats.firstOrNull { it.id == id }

    fun openOrCreateChat(contact: Contact): Chat {
        chats.firstOrNull { it.contactId == contact.id && !it.isGroup }?.let { return it }
        val chat = Chat(
            id = "chat_" + contact.id,
            title = contact.name,
            contactId = contact.id,
            lastTime = TimeUtils.nowLabel()
        )
        chats.add(0, chat)
        notifyChanged()
        return chat
    }

    fun createGroup(name: String, members: List<Contact>): Chat {
        val chat = Chat(
            id = "group_" + UUID.randomUUID().toString().take(8),
            title = name,
            isGroup = true,
            lastMessage = "Group created",
            lastTime = TimeUtils.nowLabel(),
            memberIds = members.map { it.id }
        )
        chats.add(0, chat)
        messagesFor(chat.id).add(
            Message(chatId = chat.id, senderId = "system", text = "Group created", time = TimeUtils.nowLabel())
        )
        notifyChanged()
        return chat
    }

    fun myStatus(): StatusItem = StatusItem(
        id = "mine", contactId = ME, name = profile.name,
        timeLabel = "", caption = "", bgColor = Color.parseColor("#0B3D2E")
    )

    fun addMyStatus(caption: String) {
        statuses.add(
            0,
            StatusItem(
                id = "mine_" + System.currentTimeMillis(),
                contactId = ME,
                name = profile.name,
                timeLabel = "Just now",
                caption = caption,
                bgColor = Color.parseColor("#0B3D2E")
            )
        )
        notifyChanged()
    }
}
