package com.ahaan.talkie.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.Contact
import com.ahaan.talkie.util.AvatarUtils

/**
 * Contacts list used by both New Chat (single tap opens chat) and
 * New Group (multi-select with checkboxes).
 */
class ContactsAdapter(
    private val selectionMode: Boolean,
    private val onClick: (Contact) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    sealed class Row {
        data class Header(val title: String) : Row()
        data class Entry(val contact: Contact) : Row()
    }

    private var rows: List<Row> = emptyList()
    val selected: MutableSet<String> = mutableSetOf()

    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    fun selectedContacts(all: List<Contact>): List<Contact> =
        all.filter { selected.contains(it.id) }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Header -> 0
        is Row.Entry -> 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 0) {
            HeaderHolder(inflater.inflate(R.layout.item_section_header, parent, false))
        } else {
            ContactHolder(inflater.inflate(R.layout.item_contact, parent, false))
        }
    }

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderHolder).title.text = row.title
            is Row.Entry -> {
                val h = holder as ContactHolder
                val contact = row.contact
                AvatarUtils.applyAvatar(h.avatar, contact.name)
                h.name.text = contact.name
                h.about.text = if (contact.fromDevice) contact.phone else contact.about
                if (selectionMode) {
                    h.check.visibility = View.VISIBLE
                    h.check.isChecked = selected.contains(contact.id)
                } else {
                    h.check.visibility = View.GONE
                }
                holder.itemView.setOnClickListener {
                    if (selectionMode) {
                        if (selected.contains(contact.id)) selected.remove(contact.id)
                        else selected.add(contact.id)
                        notifyItemChanged(position)
                    }
                    onClick(contact)
                }
            }
        }
    }

    class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.sectionTitle)
    }

    class ContactHolder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.contactAvatar)
        val name: TextView = view.findViewById(R.id.contactName)
        val about: TextView = view.findViewById(R.id.contactAbout)
        val check: CheckBox = view.findViewById(R.id.contactCheck)
    }
}
