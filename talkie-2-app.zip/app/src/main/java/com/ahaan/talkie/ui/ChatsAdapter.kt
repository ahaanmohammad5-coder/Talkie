package com.ahaan.talkie.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.Chat
import com.ahaan.talkie.util.AvatarUtils
import com.ahaan.talkie.util.TickUi

class ChatsAdapter(
    private val onClick: (Chat) -> Unit
) : RecyclerView.Adapter<ChatsAdapter.Holder>() {

    private var items: List<Chat> = emptyList()

    fun submit(list: List<Chat>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return Holder(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val chat = items[position]
        AvatarUtils.applyAvatar(holder.avatar, chat.title)
        holder.name.text = chat.title
        holder.time.text = chat.lastTime
        holder.preview.text = chat.lastMessage
        if (chat.lastFromMe) {
            TickUi.apply(holder.tick, chat.lastStatus)
        } else {
            holder.tick.visibility = View.GONE
        }
        if (chat.unread > 0) {
            holder.badge.visibility = View.VISIBLE
            holder.badge.text = chat.unread.toString()
            holder.time.setTextColor(
                androidx.core.content.ContextCompat.getColor(holder.itemView.context, R.color.green_badge)
            )
        } else {
            holder.badge.visibility = View.GONE
            holder.time.setTextColor(
                androidx.core.content.ContextCompat.getColor(holder.itemView.context, R.color.text_muted)
            )
        }
        holder.itemView.setOnClickListener { onClick(chat) }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.chatAvatar)
        val name: TextView = view.findViewById(R.id.chatName)
        val time: TextView = view.findViewById(R.id.chatTime)
        val preview: TextView = view.findViewById(R.id.chatPreview)
        val tick: ImageView = view.findViewById(R.id.chatTick)
        val badge: TextView = view.findViewById(R.id.chatBadge)
    }
}
