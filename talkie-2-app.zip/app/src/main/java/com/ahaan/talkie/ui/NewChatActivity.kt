package com.ahaan.talkie.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.Contact
import com.ahaan.talkie.data.DemoRepository
import com.google.android.material.appbar.MaterialToolbar

/**
 * New chat: shows Talkie sample contacts and, after READ_CONTACTS is
 * granted, the real contacts from this phone merged in.
 */
class NewChatActivity : AppCompatActivity() {

    private lateinit var adapter: ContactsAdapter
    private lateinit var note: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) loadDeviceContacts()
        else showSamplesOnly()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_chat)

        val toolbar = findViewById<MaterialToolbar>(R.id.newChatToolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }

        note = findViewById(R.id.contactsNote)
        val rv = findViewById<RecyclerView>(R.id.contactsList)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ContactsAdapter(selectionMode = false) { contact ->
            val chat = DemoRepository.openOrCreateChat(contact)
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra(ChatActivity.EXTRA_CHAT_ID, chat.id)
            startActivity(intent)
            finish()
        }
        rv.adapter = adapter

        showSamplesOnly()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            loadDeviceContacts()
        } else {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private fun showSamplesOnly() {
        note.visibility = View.VISIBLE
        note.text = getString(R.string.contacts_permission_note)
        val rows = mutableListOf<ContactsAdapter.Row>()
        rows.add(ContactsAdapter.Row.Header(getString(R.string.sample_contacts)))
        DemoRepository.contacts.forEach { rows.add(ContactsAdapter.Row.Entry(it)) }
        adapter.submit(rows)
    }

    private fun loadDeviceContacts() {
        val deviceContacts = mutableListOf<Contact>()
        try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            contentResolver.query(uri, projection, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { cursor ->
                val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val seen = mutableSetOf<String>()
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameIdx) ?: continue
                    val number = cursor.getString(numIdx) ?: ""
                    val key = name + "|" + number.filter { it.isDigit() }
                    if (!seen.add(key)) continue
                    val deviceId = "device_" + cursor.getLong(idIdx) + "_" + deviceContacts.size
                    deviceContacts.add(
                        Contact(
                            id = deviceId,
                            name = name,
                            phone = number,
                            about = number,
                            fromDevice = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Contacts provider unavailable: fall back to samples silently.
        }

        note.visibility = View.GONE
        val rows = mutableListOf<ContactsAdapter.Row>()
        rows.add(ContactsAdapter.Row.Header(getString(R.string.sample_contacts)))
        DemoRepository.contacts.forEach { rows.add(ContactsAdapter.Row.Entry(it)) }
        if (deviceContacts.isNotEmpty()) {
            rows.add(ContactsAdapter.Row.Header(getString(R.string.contacts_on_device)))
            // Merge device contacts into the repository so chats can be
            // opened with them, without duplicating names already present.
            val knownNames = DemoRepository.contacts.map { it.name.lowercase() }.toSet()
            deviceContacts.forEach { dc ->
                if (!knownNames.contains(dc.name.lowercase()) &&
                    DemoRepository.contacts.none { it.id == dc.id }
                ) {
                    DemoRepository.contacts.add(dc)
                }
            }
            deviceContacts.forEach { rows.add(ContactsAdapter.Row.Entry(it)) }
        }
        adapter.submit(rows)
    }
}
