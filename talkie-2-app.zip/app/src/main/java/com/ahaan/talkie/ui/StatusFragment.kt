package com.ahaan.talkie.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository

class StatusFragment : Fragment() {

    private lateinit var adapter: StatusAdapter
    private val listener: () -> Unit = { refresh() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_list, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val rv = view.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = StatusAdapter(
            onMyStatusClick = { showAddStatusDialog() },
            onStatusClick = { item ->
                val intent = Intent(requireContext(), StatusViewActivity::class.java)
                intent.putExtra(StatusViewActivity.EXTRA_STATUS_ID, item.id)
                startActivity(intent)
            }
        )
        rv.adapter = adapter
        refresh()
    }

    override fun onStart() {
        super.onStart()
        DemoRepository.addListener(listener)
        refresh()
    }

    override fun onStop() {
        DemoRepository.removeListener(listener)
        super.onStop()
    }

    private fun refresh() {
        if (!::adapter.isInitialized) return
        val rows = mutableListOf<StatusAdapter.Row>()
        rows.add(StatusAdapter.Row.MyStatus)
        rows.add(StatusAdapter.Row.Header(getString(R.string.recent_updates)))
        DemoRepository.statuses.forEach { rows.add(StatusAdapter.Row.Entry(it)) }
        adapter.submit(rows)
    }

    private fun showAddStatusDialog() {
        val input = EditText(requireContext())
        input.hint = "Status text likhein"
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.my_status))
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    DemoRepository.addMyStatus(text)
                    Toast.makeText(requireContext(), "Status added", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
