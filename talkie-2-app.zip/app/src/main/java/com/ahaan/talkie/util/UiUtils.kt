package com.ahaan.talkie.util

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Avatar helpers: colored circle with initials, no images needed. */
object AvatarUtils {

    private val palette = listOf(
        "#0E4D38", "#1E7A55", "#7A4E2D", "#3D5A80", "#6D4C7D",
        "#8A6D3B", "#2F6F6A", "#955251", "#4A6FA5", "#5B7553"
    ).map { Color.parseColor(it) }

    fun colorFor(seed: String): Int {
        val idx = abs(seed.hashCode()) % palette.size
        return palette[idx]
    }

    fun initials(name: String): String {
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return when {
            parts.isEmpty() -> "?"
            parts.size == 1 -> parts[0].take(2).uppercase(Locale.getDefault())
            else -> (parts[0].take(1) + parts[1].take(1)).uppercase(Locale.getDefault())
        }
    }

    /** Paints a TextView as a round avatar with initials. */
    fun applyAvatar(view: TextView, name: String) {
        view.text = initials(name)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(colorFor(name))
        view.background = bg
    }
}

/** Shared tick / clock rendering for own-message delivery states. */
object TickUi {

    fun apply(imageView: android.widget.ImageView, status: com.ahaan.talkie.data.MessageStatus?) {
        val ctx = imageView.context
        when (status) {
            null -> imageView.visibility = android.view.View.GONE
            com.ahaan.talkie.data.MessageStatus.PENDING -> {
                imageView.visibility = android.view.View.VISIBLE
                imageView.setImageResource(com.ahaan.talkie.R.drawable.ic_clock)
                imageView.imageTintList = android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(ctx, com.ahaan.talkie.R.color.tick_gray)
                )
            }
            com.ahaan.talkie.data.MessageStatus.SENT -> {
                imageView.visibility = android.view.View.VISIBLE
                imageView.setImageResource(com.ahaan.talkie.R.drawable.ic_tick_single)
                imageView.imageTintList = android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(ctx, com.ahaan.talkie.R.color.tick_gray)
                )
            }
            com.ahaan.talkie.data.MessageStatus.DELIVERED -> {
                imageView.visibility = android.view.View.VISIBLE
                imageView.setImageResource(com.ahaan.talkie.R.drawable.ic_tick_double)
                imageView.imageTintList = android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(ctx, com.ahaan.talkie.R.color.tick_gray)
                )
            }
            com.ahaan.talkie.data.MessageStatus.READ -> {
                imageView.visibility = android.view.View.VISIBLE
                imageView.setImageResource(com.ahaan.talkie.R.drawable.ic_tick_double)
                imageView.imageTintList = android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(ctx, com.ahaan.talkie.R.color.tick_blue)
                )
            }
        }
    }
}

object TimeUtils {

    fun nowLabel(): String =
        SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

    fun formatDuration(totalSec: Int): String {
        val m = totalSec / 60
        val s = totalSec % 60
        return String.format(Locale.getDefault(), "%d:%02d", m, s)
    }
}
