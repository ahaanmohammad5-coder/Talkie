package com.ahaan.talkie.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.util.AvatarUtils
import com.google.android.material.appbar.MaterialToolbar

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<MaterialToolbar>(R.id.settingsToolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }

        val profile = DemoRepository.profile
        AvatarUtils.applyAvatar(findViewById(R.id.settingsAvatar), profile.name)
        findViewById<TextView>(R.id.settingsName).text = profile.name
        findViewById<TextView>(R.id.settingsAbout).text = profile.about

        findViewById<View>(R.id.settingsProfileRow).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        findViewById<View>(R.id.settingNotifications).setOnClickListener {
            Toast.makeText(this, "Notifications are on", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.settingPrivacy).setOnClickListener {
            Toast.makeText(this, "Privacy: everyone can see your profile photo", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.settingStorage).setOnClickListener {
            Toast.makeText(this, "Storage is managed automatically", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.settingAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }
}
