package com.ahaan.talkie.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.CallDirection
import com.ahaan.talkie.data.CallLogItem
import com.ahaan.talkie.util.AvatarUtils

class CallsAdapter(
    private val onCallClick: (CallLogItem, Boolean) -> Unit
) : RecyclerView.Adapter<CallsAdapter.Holder>() {

    private var items: List<CallLogItem> = emptyList()

    fun submit(list: List<CallLogItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_call, parent, false)
        return Holder(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val ctx = holder.itemView.context
        AvatarUtils.applyAvatar(holder.avatar, item.name)
        holder.name.text = item.name
        holder.time.text = item.timeLabel
        if (item.direction == CallDirection.MISSED) {
            holder.name.setTextColor(ContextCompat.getColor(ctx, R.color.red_call))
        } else {
            holder.name.setTextColor(ContextCompat.getColor(ctx, R.color.text_dark))
        }
        val arrowRes = when (item.direction) {
            CallDirection.INCOMING -> R.drawable.ic_arrow_in
            CallDirection.OUTGOING -> R.drawable.ic_arrow_out
            CallDirection.MISSED -> R.drawable.ic_arrow_in
        }
        val arrowColor = when (item.direction) {
            CallDirection.MISSED -> R.color.red_call
            else -> R.color.green_badge
        }
        holder.direction.setImageResource(arrowRes)
        holder.direction.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(ctx, arrowColor)
        )
        holder.action.setImageResource(if (item.isVideo) R.drawable.ic_videocam else R.drawable.ic_call)
        holder.action.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(ctx, R.color.green_primary)
        )
        holder.action.setOnClickListener { onCallClick(item, item.isVideo) }
        holder.itemView.setOnClickListener { onCallClick(item, item.isVideo) }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.callAvatar)
        val name: TextView = view.findViewById(R.id.callName)
        val time: TextView = view.findViewById(R.id.callTime)
        val direction: ImageView = view.findViewById(R.id.callDirection)
        val action: ImageButton = view.findViewById(R.id.callActionBtn)
    }
}
