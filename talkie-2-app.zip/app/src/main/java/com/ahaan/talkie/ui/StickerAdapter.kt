package com.ahaan.talkie.ui

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import java.io.File

/** One cell in a sticker grid. */
sealed class StickerItem {
    data class Glyph(val glyph: String) : StickerItem()
    data class Custom(val file: File) : StickerItem()
    object Create : StickerItem()
}

class StickerAdapter(
    private val onPick: (StickerItem) -> Unit
) : RecyclerView.Adapter<StickerAdapter.Holder>() {

    private var items: List<StickerItem> = emptyList()

    fun submit(list: List<StickerItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_sticker, parent, false)
        return Holder(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.image.visibility = View.GONE
        holder.glyph.visibility = View.GONE
        holder.create.visibility = View.GONE
        when (item) {
            is StickerItem.Glyph -> {
                holder.glyph.visibility = View.VISIBLE
                holder.glyph.text = item.glyph
            }
            is StickerItem.Custom -> {
                val bmp = BitmapFactory.decodeFile(item.file.absolutePath)
                if (bmp != null) {
                    holder.image.visibility = View.VISIBLE
                    holder.image.setImageBitmap(bmp)
                } else {
                    holder.glyph.visibility = View.VISIBLE
                    holder.glyph.text = "★"
                }
            }
            StickerItem.Create -> holder.create.visibility = View.VISIBLE
        }
        holder.itemView.setOnClickListener { onPick(item) }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.stickerImage)
        val glyph: TextView = view.findViewById(R.id.stickerGlyph)
        val create: LinearLayout = view.findViewById(R.id.stickerCreateTile)
    }
}
