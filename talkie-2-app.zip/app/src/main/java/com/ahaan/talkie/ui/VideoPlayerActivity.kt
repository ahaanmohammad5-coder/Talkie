package com.ahaan.talkie.ui

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import com.ahaan.talkie.R

/** Simple in-app video player for shared videos and video notes. */
class VideoPlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "extra_video_uri"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_player)

        val uriString = intent.getStringExtra(EXTRA_URI)
        val videoView = findViewById<VideoView>(R.id.videoView)
        findViewById<android.view.View>(R.id.playerClose).setOnClickListener { finish() }

        if (uriString != null) {
            videoView.setMediaController(MediaController(this))
            videoView.setVideoURI(Uri.parse(uriString))
            videoView.setOnPreparedListener { it.start() }
        } else {
            finish()
        }
    }
}
