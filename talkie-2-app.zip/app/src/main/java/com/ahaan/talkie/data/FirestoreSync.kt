package com.ahaan.talkie.data

import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

/**
 * Live-mode bridge to Firebase Firestore.
 *
 * Everything here is defensive: if Firebase is not configured (no
 * google-services.json), every call quietly does nothing and the app keeps
 * running on [DemoRepository] alone. When the file IS added, messages are
 * mirrored to Firestore and a snapshot listener is attached so two phones
 * can sync. Collections used: "messages" (one doc per message), "chats".
 *
 * NOTE for the owner: Firestore security rules and Auth sign-in still need
 * to be set up in the Firebase console for real multi-user use. See README.
 */
object FirestoreSync {

    private const val TAG = "FirestoreSync"

    @Volatile
    var liveMode: Boolean = false
        private set

    private var listenerStarted = false

    /** Called once from TalkieApp after FirebaseApp initialization attempt. */
    fun init() {
        liveMode = try {
            FirebaseApp.getInstance() != null
        } catch (e: Exception) {
            false
        }
        if (liveMode) startListeners()
    }

    private fun dbOrNull(): FirebaseFirestore? = try {
        if (liveMode) FirebaseFirestore.getInstance() else null
    } catch (e: Exception) {
        Log.w(TAG, "Firestore unavailable", e)
        null
    }

    fun uploadMessage(message: Message) {
        val db = dbOrNull() ?: return
        val data = hashMapOf(
            "chatId" to message.chatId,
            "senderId" to message.senderId,
            "senderName" to message.senderName,
            "type" to message.type.name,
            "text" to message.text,
            "mediaUri" to message.mediaUri,
            "latitude" to message.latitude,
            "longitude" to message.longitude,
            "durationSec" to message.durationSec,
            "time" to message.time,
            "status" to message.status.name,
            "createdAt" to System.currentTimeMillis()
        )
        db.collection("messages").document(message.id).set(data)
            .addOnFailureListener { e -> Log.w(TAG, "Message mirror failed", e) }
    }

    fun onLocalDataChanged() {
        // Chat list previews could be mirrored here in a fuller live build.
    }

    private fun startListeners() {
        if (listenerStarted) return
        listenerStarted = true
        val db = dbOrNull() ?: return
        // Live listener: newest messages across chats. A production build
        // would scope this per open chat and merge into DemoRepository;
        // the merge point is marked here so the wiring is ready.
        db.collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { _, error ->
                if (error != null) Log.w(TAG, "Listen failed", error)
                // MERGE POINT: convert docs to Message and add to
                // DemoRepository when they are not already present.
            }
    }
}
