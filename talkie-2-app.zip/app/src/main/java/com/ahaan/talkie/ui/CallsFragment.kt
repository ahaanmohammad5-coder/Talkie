package com.ahaan.talkie.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository

class CallsFragment : Fragment() {

    private lateinit var adapter: CallsAdapter
    private val listener: () -> Unit = { refresh() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_list, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val rv = view.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = CallsAdapter { item, isVideo ->
            val intent = Intent(requireContext(), CallActivity::class.java)
            intent.putExtra(CallActivity.EXTRA_NAME, item.name)
            intent.putExtra(CallActivity.EXTRA_CONTACT_ID, item.contactId)
            intent.putExtra(CallActivity.EXTRA_IS_VIDEO, isVideo)
            startActivity(intent)
        }
        rv.adapter = adapter
        refresh()
    }

    override fun onStart() {
        super.onStart()
        DemoRepository.addListener(listener)
        refresh()
    }

    override fun onStop() {
        DemoRepository.removeListener(listener)
        super.onStop()
    }

    private fun refresh() {
        if (::adapter.isInitialized) adapter.submit(DemoRepository.callLogs.toList())
    }
}
