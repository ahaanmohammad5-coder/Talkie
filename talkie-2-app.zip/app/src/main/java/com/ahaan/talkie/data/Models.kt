package com.ahaan.talkie.data

import java.util.UUID

/** Message kinds Talkie can render in a chat. */
enum class MessageType { TEXT, IMAGE, VIDEO, VIDEO_NOTE, STICKER, LOCATION, VOICE }

/**
 * Delivery state machine for own messages:
 * PENDING (clock icon, no internet, waits in queue) ->
 * SENT (single tick) -> DELIVERED (double tick) -> READ (blue double tick).
 */
enum class MessageStatus { PENDING, SENT, DELIVERED, READ }

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val chatId: String,
    val senderId: String,               // "me" for own messages, else contact id
    val senderName: String = "",
    val type: MessageType = MessageType.TEXT,
    val text: String = "",
    val mediaUri: String? = null,       // image / video / video note / voice file
    val stickerGlyph: String? = null,   // built-in sticker shown as a big glyph
    val stickerPath: String? = null,    // custom sticker file in app storage
    val latitude: Double? = null,
    val longitude: Double? = null,
    val durationSec: Int = 0,
    val time: String = "",
    var status: MessageStatus = MessageStatus.SENT
) {
    val isMine: Boolean get() = senderId == "me"
}

data class Chat(
    val id: String,
    val title: String,
    val isGroup: Boolean = false,
    val contactId: String? = null,
    var lastMessage: String = "",
    var lastTime: String = "",
    var lastStatus: MessageStatus? = null,
    var lastFromMe: Boolean = false,
    var unread: Int = 0,
    val memberIds: List<String> = emptyList()
)

data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val about: String = "Hey there! I am using Talkie.",
    var isOnline: Boolean = false,
    var lastSeen: String = "last seen recently",
    val fromDevice: Boolean = false
)

data class StatusItem(
    val id: String,
    val contactId: String,
    val name: String,
    val timeLabel: String,
    val caption: String,
    val bgColor: Int
)

enum class CallDirection { INCOMING, OUTGOING, MISSED }

data class CallLogItem(
    val id: String,
    val name: String,
    val contactId: String?,
    val direction: CallDirection,
    val isVideo: Boolean,
    val timeLabel: String
)

data class MyProfile(
    var name: String = "Ahaan",
    var about: String = "UI/UX Designer",
    var phone: String = "+92 312 0649319"
)
