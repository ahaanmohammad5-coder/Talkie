package com.ahaan.talkie.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.StatusItem
import com.ahaan.talkie.util.AvatarUtils

/**
 * Status list with two row kinds: the "My Status" header row and normal
 * recent-update rows. Headers between sections are simple text rows.
 */
class StatusAdapter(
    private val onMyStatusClick: () -> Unit,
    private val onStatusClick: (StatusItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    sealed class Row {
        object MyStatus : Row()
        data class Header(val title: String) : Row()
        data class Entry(val item: StatusItem) : Row()
    }

    private var rows: List<Row> = emptyList()

    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.MyStatus -> 0
        is Row.Header -> 1
        is Row.Entry -> 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            1 -> HeaderHolder(inflater.inflate(R.layout.item_section_header, parent, false))
            0 -> StatusHolder(inflater.inflate(R.layout.item_status, parent, false), true)
            else -> StatusHolder(inflater.inflate(R.layout.item_status, parent, false), false)
        }
    }

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderHolder).title.text = row.title
            is Row.MyStatus -> {
                val h = holder as StatusHolder
                val me = com.ahaan.talkie.data.DemoRepository.profile
                AvatarUtils.applyAvatar(h.avatar, me.name)
                h.name.text = holder.itemView.context.getString(R.string.my_status)
                h.time.text = holder.itemView.context.getString(R.string.my_status_sub)
                h.plus.visibility = View.VISIBLE
                h.ring.background = null
                holder.itemView.setOnClickListener { onMyStatusClick() }
            }
            is Row.Entry -> {
                val h = holder as StatusHolder
                AvatarUtils.applyAvatar(h.avatar, row.item.name)
                h.name.text = row.item.name
                h.time.text = row.item.timeLabel
                h.plus.visibility = View.GONE
                h.ring.setBackgroundResource(R.drawable.bg_status_ring)
                holder.itemView.setOnClickListener { onStatusClick(row.item) }
            }
        }
    }

    class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.sectionTitle)
    }

    class StatusHolder(view: View, isMine: Boolean) : RecyclerView.ViewHolder(view) {
        val ring: FrameLayout = view.findViewById(R.id.statusRing)
        val avatar: TextView = view.findViewById(R.id.statusAvatar)
        val name: TextView = view.findViewById(R.id.statusName)
        val time: TextView = view.findViewById(R.id.statusTime)
        val plus: ImageView = view.findViewById(R.id.statusPlus)
    }
}
