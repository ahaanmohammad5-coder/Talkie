package com.ahaan.talkie.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.ahaan.talkie.R

/**
 * Splash: the bubble icon scales in with a soft overshoot, the word
 * "Talkie" fades and slides up under it, then MainActivity opens with a
 * fade transition.
 */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<ImageView>(R.id.splashLogo)
        val title = findViewById<TextView>(R.id.splashTitle)
        val tagline = findViewById<TextView>(R.id.splashTagline)

        // Start small and invisible, then pop in with a slight overshoot.
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.alpha = 0f

        val scaleX = ObjectAnimator.ofFloat(logo, "scaleX", 0.6f, 1.0f)
        val scaleY = ObjectAnimator.ofFloat(logo, "scaleY", 0.6f, 1.0f)
        val fade = ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f)
        val popSet = AnimatorSet()
        popSet.playTogether(scaleX, scaleY, fade)
        popSet.duration = 900
        popSet.interpolator = OvershootInterpolator(1.6f)
        popSet.start()

        // Wordmark fades and slides up shortly after the icon lands.
        title.translationY = 24f
        val titleFade = ObjectAnimator.ofFloat(title, "alpha", 0f, 1f)
        val titleSlide = ObjectAnimator.ofFloat(title, "translationY", 24f, 0f)
        val titleSet = AnimatorSet()
        titleSet.playTogether(titleFade, titleSlide)
        titleSet.duration = 480
        titleSet.startDelay = 650
        titleSet.start()

        tagline.translationY = 16f
        val tagSet = AnimatorSet()
        tagSet.playTogether(
            ObjectAnimator.ofFloat(tagline, "alpha", 0f, 1f),
            ObjectAnimator.ofFloat(tagline, "translationY", 16f, 0f)
        )
        tagSet.duration = 420
        tagSet.startDelay = 950
        tagSet.start()

        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
