package com.ahaan.talkie.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

/**
 * Home screen: toolbar + CHATS / STATUS / CALLS tabs.
 * The FAB changes meaning per tab, like WhatsApp.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var fab: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.mainToolbar)
        toolbar.inflateMenu(R.menu.menu_main)
        toolbar.setOnMenuItemClickListener { item -> onMenuItem(item) }

        viewPager = findViewById(R.id.viewPager)
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        fab = findViewById(R.id.mainFab)

        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 3
            override fun createFragment(position: Int): Fragment = when (position) {
                0 -> ChatsFragment()
                1 -> StatusFragment()
                else -> CallsFragment()
            }
        }

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_chats)
                1 -> getString(R.string.tab_status)
                else -> getString(R.string.tab_calls)
            }
        }.attach()

        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateFab(position)
            }
        })
        updateFab(0)

        fab.setOnClickListener {
            when (viewPager.currentItem) {
                0 -> startActivity(Intent(this, NewChatActivity::class.java))
                1 -> showAddStatusDialog()
                else -> startActivity(Intent(this, NewChatActivity::class.java))
            }
        }

        requestNotificationPermissionIfNeeded()
    }

    private fun updateFab(position: Int) {
        fab.setImageResource(
            when (position) {
                0 -> R.drawable.ic_chat
                1 -> R.drawable.ic_edit
                else -> R.drawable.ic_call
            }
        )
        val cd = when (position) {
            0 -> R.string.new_chat
            1 -> R.string.my_status
            else -> R.string.tab_calls
        }
        fab.contentDescription = getString(cd)
    }

    private fun showAddStatusDialog() {
        val input = android.widget.EditText(this)
        input.hint = "Kuch likh dein apne status ke liye"
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.my_status))
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    DemoRepository.addMyStatus(text)
                    Toast.makeText(this, "Status added", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onMenuItem(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_group -> {
                startActivity(Intent(this, NewGroupActivity::class.java)); true
            }
            R.id.action_profile -> {
                startActivity(Intent(this, ProfileActivity::class.java)); true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java)); true
            }
            else -> false
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001
                )
            }
        }
    }
}
