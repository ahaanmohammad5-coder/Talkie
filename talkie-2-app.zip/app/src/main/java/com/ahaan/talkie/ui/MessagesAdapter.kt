package com.ahaan.talkie.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.Chat
import com.ahaan.talkie.data.Message
import com.ahaan.talkie.data.MessageType
import com.ahaan.talkie.util.TickUi
import com.ahaan.talkie.util.TimeUtils

/**
 * Renders every message type in one flexible row layout:
 * text, image, video (play overlay + duration), circular video note,
 * sticker (glyph or custom file), location card and voice note.
 * Bubble side, colors and ticks follow the sender and delivery state.
 */
class MessagesAdapter(
    private val chat: Chat,
    private val onMediaClick: (Message) -> Unit,
    private val onLocationClick: (Message) -> Unit
) : RecyclerView.Adapter<MessagesAdapter.Holder>() {

    private var items: List<Message> = emptyList()

    private var player: MediaPlayer? = null
    private var playingId: String? = null

    fun submit(list: List<Message>) {
        items = list
        notifyDataSetChanged()
    }

    fun releasePlayer() {
        player?.release()
        player = null
        playingId = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return Holder(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val msg = items[position]
        val ctx = holder.itemView.context
        val mine = msg.isMine

        // Position the bubble left (received) or right (sent).
        val params = holder.bubble.layoutParams as LinearLayout.LayoutParams
        params.gravity = if (mine) Gravity.END else Gravity.START
        holder.bubble.layoutParams = params

        val isSticker = msg.type == MessageType.STICKER
        if (isSticker) {
            holder.bubble.background = null
            holder.bubble.setPadding(4, 2, 4, 2)
        } else {
            holder.bubble.setBackgroundResource(
                if (mine) R.drawable.bg_bubble_sent else R.drawable.bg_bubble_received
            )
            val pad = (10 * ctx.resources.displayMetrics.density).toInt()
            holder.bubble.setPadding(pad, pad - 3, pad, pad - 4)
        }

        val mainTextColor = ContextCompat.getColor(ctx, if (mine) R.color.white else R.color.text_dark)
        val metaColor = ContextCompat.getColor(ctx, if (mine) R.color.beige_accent else R.color.text_muted)

        // Group sender name on received messages inside groups.
        if (chat.isGroup && !mine && msg.senderName.isNotEmpty()) {
            holder.senderName.visibility = View.VISIBLE
            holder.senderName.text = msg.senderName
        } else {
            holder.senderName.visibility = View.GONE
        }

        // Reset all type blocks, then show the one we need.
        holder.text.visibility = View.GONE
        holder.media.visibility = View.GONE
        holder.videoNote.visibility = View.GONE
        holder.stickerImage.visibility = View.GONE
        holder.stickerGlyph.visibility = View.GONE
        holder.location.visibility = View.GONE
        holder.voice.visibility = View.GONE

        when (msg.type) {
            MessageType.TEXT -> {
                holder.text.visibility = View.VISIBLE
                holder.text.text = msg.text
                holder.text.setTextColor(mainTextColor)
            }
            MessageType.IMAGE -> {
                holder.media.visibility = View.VISIBLE
                holder.videoOverlay.visibility = View.GONE
                if (msg.mediaUri != null) {
                    holder.image.setImageURI(Uri.parse(msg.mediaUri))
                }
                holder.media.setOnClickListener { onMediaClick(msg) }
            }
            MessageType.VIDEO -> {
                holder.media.visibility = View.VISIBLE
                holder.videoOverlay.visibility = View.VISIBLE
                val thumb = videoThumbnail(ctx, msg.mediaUri)
                if (thumb != null) holder.image.setImageBitmap(thumb)
                else if (msg.mediaUri != null) runCatching { holder.image.setImageURI(Uri.parse(msg.mediaUri)) }
                val dur = if (msg.durationSec > 0) msg.durationSec else videoDurationSec(ctx, msg.mediaUri)
                holder.videoDuration.text = TimeUtils.formatDuration(dur)
                holder.media.setOnClickListener { onMediaClick(msg) }
            }
            MessageType.VIDEO_NOTE -> {
                holder.videoNote.visibility = View.VISIBLE
                val thumb = videoThumbnail(ctx, msg.mediaUri)
                if (thumb != null) holder.videoNoteThumb.setImageBitmap(circleBitmap(thumb))
                holder.videoNote.setOnClickListener { onMediaClick(msg) }
            }
            MessageType.STICKER -> {
                if (!msg.stickerGlyph.isNullOrEmpty()) {
                    holder.stickerGlyph.visibility = View.VISIBLE
                    holder.stickerGlyph.text = msg.stickerGlyph
                } else if (!msg.stickerPath.isNullOrEmpty()) {
                    val bmp = BitmapFactory.decodeFile(msg.stickerPath)
                    if (bmp != null) {
                        holder.stickerImage.visibility = View.VISIBLE
                        holder.stickerImage.setImageBitmap(bmp)
                    } else {
                        holder.stickerGlyph.visibility = View.VISIBLE
                        holder.stickerGlyph.text = "★"
                    }
                }
            }
            MessageType.LOCATION -> {
                holder.location.visibility = View.VISIBLE
                holder.locationText.text = msg.text
                holder.locationText.setTextColor(mainTextColor)
                holder.location.setOnClickListener { onLocationClick(msg) }
            }
            MessageType.VOICE -> {
                holder.voice.visibility = View.VISIBLE
                holder.voiceDuration.text = TimeUtils.formatDuration(msg.durationSec)
                holder.voiceDuration.setTextColor(metaColor)
                val isPlaying = playingId == msg.id
                holder.voicePlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                holder.voicePlay.imageTintList = android.content.res.ColorStateList.valueOf(mainTextColor)
                holder.voicePlay.setOnClickListener { toggleVoice(holder, msg) }
            }
        }

        holder.time.text = msg.time
        holder.time.setTextColor(metaColor)
        if (mine) {
            TickUi.apply(holder.tick, msg.status)
        } else {
            holder.tick.visibility = View.GONE
        }
    }

    private fun toggleVoice(holder: Holder, msg: Message) {
        val uri = msg.mediaUri ?: return
        if (playingId == msg.id) {
            releasePlayer()
            notifyDataSetChanged()
            return
        }
        releasePlayer()
        player = MediaPlayer().apply {
            try {
                if (uri.startsWith("content://") || uri.startsWith("file://")) {
                    setDataSource(holder.itemView.context, Uri.parse(uri))
                } else {
                    setDataSource(uri)
                }
                setOnCompletionListener {
                    playingId = null
                    notifyDataSetChanged()
                }
                prepare()
                start()
            } catch (e: Exception) {
                releasePlayer()
            }
        }
        playingId = msg.id
        notifyDataSetChanged()
    }

    private fun videoThumbnail(context: android.content.Context, uriString: String?): Bitmap? {
        if (uriString == null) return null
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, Uri.parse(uriString))
            retriever.getFrameAtTime(0)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun videoDurationSec(context: android.content.Context, uriString: String?): Int {
        if (uriString == null) return 0
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, Uri.parse(uriString))
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            (ms / 1000).toInt()
        } catch (e: Exception) {
            0
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Crops a bitmap into a circle for video-note bubbles. */
    private fun circleBitmap(src: Bitmap): Bitmap {
        val size = minOf(src.width, src.height)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = Rect(0, 0, size, size)
        val srcRect = Rect(
            (src.width - size) / 2, (src.height - size) / 2,
            (src.width - size) / 2 + size, (src.height - size) / 2 + size
        )
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, srcRect, rect, paint)
        return output
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val bubble: LinearLayout = view.findViewById(R.id.bubble)
        val senderName: TextView = view.findViewById(R.id.msgSenderName)
        val text: TextView = view.findViewById(R.id.msgText)
        val media: FrameLayout = view.findViewById(R.id.mediaContainer)
        val image: ImageView = view.findViewById(R.id.msgImage)
        val videoOverlay: View = view.findViewById(R.id.videoOverlay)
        val videoDuration: TextView = view.findViewById(R.id.msgVideoDuration)
        val videoNote: FrameLayout = view.findViewById(R.id.videoNoteContainer)
        val videoNoteThumb: ImageView = view.findViewById(R.id.msgVideoNoteThumb)
        val stickerImage: ImageView = view.findViewById(R.id.msgStickerImage)
        val stickerGlyph: TextView = view.findViewById(R.id.msgStickerGlyph)
        val location: LinearLayout = view.findViewById(R.id.locationContainer)
        val locationText: TextView = view.findViewById(R.id.msgLocationText)
        val voice: LinearLayout = view.findViewById(R.id.voiceContainer)
        val voicePlay: ImageButton = view.findViewById(R.id.btnVoicePlay)
        val voiceDuration: TextView = view.findViewById(R.id.msgVoiceDuration)
        val time: TextView = view.findViewById(R.id.msgTime)
        val tick: ImageView = view.findViewById(R.id.msgTick)
    }
}
