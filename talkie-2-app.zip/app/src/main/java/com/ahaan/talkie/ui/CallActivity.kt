package com.ahaan.talkie.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.util.AvatarUtils
import com.ahaan.talkie.util.TimeUtils

/**
 * Voice / video call screen. In demo mode an outgoing call simulates
 * "Ringing..." for 2 seconds, then connects and a timer runs. In live mode
 * this is where a WebRTC session would be attached (see README).
 */
class CallActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NAME = "extra_call_name"
        const val EXTRA_CONTACT_ID = "extra_call_contact_id"
        const val EXTRA_IS_VIDEO = "extra_call_is_video"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var seconds = 0
    private var timerRunnable: Runnable? = null
    private var logged = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        val name = intent.getStringExtra(EXTRA_NAME) ?: "Unknown"
        val contactId = intent.getStringExtra(EXTRA_CONTACT_ID)
        val isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, false)

        AvatarUtils.applyAvatar(findViewById(R.id.callAvatar), name)
        findViewById<TextView>(R.id.callName).text = name
        val stateView = findViewById<TextView>(R.id.callState)
        stateView.text = if (isVideo) "Video call - " + getString(R.string.ringing) else getString(R.string.ringing)

        // Simulate the other side picking up after 2 seconds.
        handler.postDelayed({
            stateView.text = TimeUtils.formatDuration(0)
            timerRunnable = object : Runnable {
                override fun run() {
                    seconds += 1
                    stateView.text = TimeUtils.formatDuration(seconds)
                    handler.postDelayed(this, 1000)
                }
            }
            handler.postDelayed(timerRunnable!!, 1000)
        }, 2000)

        val muteBtn = findViewById<ImageButton>(R.id.btnMute)
        tintCallButton(muteBtn, false)
        tintCallButton(findViewById(R.id.btnSpeaker), false)
        var muted = false
        muteBtn.setOnClickListener {
            muted = !muted
            muteBtn.setImageResource(if (muted) R.drawable.ic_mic_off else R.drawable.ic_mic)
            tintCallButton(muteBtn, muted)
            Toast.makeText(this, if (muted) "Muted" else "Unmuted", Toast.LENGTH_SHORT).show()
        }

        val speakerBtn = findViewById<ImageButton>(R.id.btnSpeaker)
        var speaker = false
        speakerBtn.setOnClickListener {
            speaker = !speaker
            tintCallButton(speakerBtn, speaker)
            Toast.makeText(this, if (speaker) "Speaker on" else "Speaker off", Toast.LENGTH_SHORT).show()
        }

        val videoBtn = findViewById<ImageButton>(R.id.btnVideoToggle)
        var videoOn = isVideo
        tintCallButton(videoBtn, videoOn)
        videoBtn.setOnClickListener {
            videoOn = !videoOn
            tintCallButton(videoBtn, videoOn)
            Toast.makeText(this, if (videoOn) "Video on" else "Video off", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageButton>(R.id.btnEndCall).setOnClickListener {
            if (!logged) {
                DemoRepository.addCallLog(name, contactId, isVideo)
                logged = true
            }
            finish()
        }
    }

    private fun tintCallButton(btn: ImageButton, active: Boolean) {
        val color = if (active) R.color.green_primary else R.color.text_muted
        btn.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(this, color)
        )
    }

    override fun onDestroy() {
        timerRunnable?.let { handler.removeCallbacks(it) }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
