package com.ahaan.talkie.ui

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton

/** Pick members, give the group a name, and land inside the new group chat. */
class NewGroupActivity : AppCompatActivity() {

    private lateinit var adapter: ContactsAdapter
    private lateinit var toolbar: MaterialToolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_group)

        toolbar = findViewById(R.id.newGroupToolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }
        updateSubtitle()

        val rv = findViewById<RecyclerView>(R.id.groupContactsList)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ContactsAdapter(selectionMode = true) { updateSubtitle() }
        rv.adapter = adapter
        adapter.submit(
            DemoRepository.contacts.map { ContactsAdapter.Row.Entry(it) }
        )

        findViewById<FloatingActionButton>(R.id.groupNextFab).setOnClickListener {
            val members = adapter.selectedContacts(DemoRepository.contacts)
            if (members.isEmpty()) {
                Toast.makeText(this, "Select at least one contact", Toast.LENGTH_SHORT).show()
            } else {
                askGroupName(members)
            }
        }
    }

    private fun updateSubtitle() {
        val count = if (::adapter.isInitialized) adapter.selected.size else 0
        toolbar.subtitle = if (count == 0) "Select contacts" else "$count selected"
    }

    private fun askGroupName(members: List<com.ahaan.talkie.data.Contact>) {
        val input = EditText(this)
        input.hint = getString(R.string.group_name_hint)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.create_group))
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Group name likh dein", Toast.LENGTH_SHORT).show()
                } else {
                    val chat = DemoRepository.createGroup(name, members)
                    val intent = Intent(this, ChatActivity::class.java)
                    intent.putExtra(ChatActivity.EXTRA_CHAT_ID, chat.id)
                    startActivity(intent)
                    finish()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
