package com.ahaan.talkie

import android.app.Application
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.data.FirestoreSync
import com.google.firebase.FirebaseApp

/**
 * Application entry point.
 *
 * Firebase is initialized defensively: without a google-services.json the
 * call returns null / throws, we catch it, and the app simply runs in local
 * demo mode on [DemoRepository]. With the file present, Firebase comes up
 * and [FirestoreSync] activates the live listeners.
 */
class TalkieApp : Application() {

    override fun onCreate() {
        super.onCreate()

        try {
            val app = FirebaseApp.initializeApp(this)
            if (app != null) {
                FirestoreSync.init()
            }
        } catch (e: Exception) {
            // No Firebase config on this build: demo mode, fully offline data.
        }

        // Watch connectivity so queued (clock icon) messages can auto-send.
        DemoRepository.startConnectivity(this)
    }
}
