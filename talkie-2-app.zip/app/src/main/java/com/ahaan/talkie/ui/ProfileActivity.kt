package com.ahaan.talkie.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.util.AvatarUtils
import com.google.android.material.appbar.MaterialToolbar

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val toolbar = findViewById<MaterialToolbar>(R.id.profileToolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }

        val profile = DemoRepository.profile
        AvatarUtils.applyAvatar(findViewById(R.id.profileAvatar), profile.name)
        val nameInput = findViewById<EditText>(R.id.profileName)
        val aboutInput = findViewById<EditText>(R.id.profileAbout)
        nameInput.setText(profile.name)
        aboutInput.setText(profile.about)
        findViewById<TextView>(R.id.profilePhone).text = profile.phone

        findViewById<Button>(R.id.profileSave).setOnClickListener {
            val newName = nameInput.text.toString().trim()
            if (newName.isNotEmpty()) profile.name = newName
            profile.about = aboutInput.text.toString().trim()
            AvatarUtils.applyAvatar(findViewById(R.id.profileAvatar), profile.name)
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show()
        }
    }
}
