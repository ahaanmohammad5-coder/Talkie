package com.ahaan.talkie.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.ahaan.talkie.R
import com.ahaan.talkie.data.DemoRepository
import com.ahaan.talkie.util.AvatarUtils

/** Full-screen status viewer with a 5 second auto-advance progress bar. */
class StatusViewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STATUS_ID = "extra_status_id"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var progress = 0
    private var ticker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status_view)

        val id = intent.getStringExtra(EXTRA_STATUS_ID)
        val item = DemoRepository.statuses.firstOrNull { it.id == id }
        if (item == null) {
            finish()
            return
        }

        findViewById<View>(R.id.statusRoot).setBackgroundColor(item.bgColor)
        AvatarUtils.applyAvatar(findViewById(R.id.statusViewAvatar), item.name)
        findViewById<TextView>(R.id.statusViewName).text = item.name
        findViewById<TextView>(R.id.statusViewTime).text = item.timeLabel
        findViewById<TextView>(R.id.statusCaption).text = item.caption
        findViewById<View>(R.id.statusClose).setOnClickListener { finish() }
        findViewById<View>(R.id.statusRoot).setOnClickListener { finish() }

        val bar = findViewById<ProgressBar>(R.id.statusProgress)
        // 5 seconds total, tick every 50 ms -> 100 steps.
        ticker = object : Runnable {
            override fun run() {
                progress += 1
                bar.progress = progress
                if (progress >= 100) {
                    finish()
                } else {
                    handler.postDelayed(this, 50)
                }
            }
        }
        handler.post(ticker!!)
    }

    override fun onDestroy() {
        ticker?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }
}
